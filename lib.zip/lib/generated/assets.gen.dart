/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart' as _svg;
import 'package:vector_graphics/vector_graphics.dart' as _vg;

class $AssetsIconsGen {
  const $AssetsIconsGen();

  /// Directory path: assets/icons/auth
  $AssetsIconsAuthGen get auth => const $AssetsIconsAuthGen();

  /// Directory path: assets/icons/benefit_content
  $AssetsIconsBenefitContentGen get benefitContent =>
      const $AssetsIconsBenefitContentGen();

  /// Directory path: assets/icons/benefits_widget
  $AssetsIconsBenefitsWidgetGen get benefitsWidget =>
      const $AssetsIconsBenefitsWidgetGen();

  /// Directory path: assets/icons/chat
  $AssetsIconsChatGen get chat => const $AssetsIconsChatGen();

  /// Directory path: assets/icons/common
  $AssetsIconsCommonGen get common => const $AssetsIconsCommonGen();

  /// Directory path: assets/icons/demo
  $AssetsIconsDemoGen get demo => const $AssetsIconsDemoGen();

  /// Directory path: assets/icons/keyboard
  $AssetsIconsKeyboardGen get keyboard => const $AssetsIconsKeyboardGen();

  /// Directory path: assets/icons/more_page
  $AssetsIconsMorePageGen get morePage => const $AssetsIconsMorePageGen();

  /// Directory path: assets/icons/navigation_bar
  $AssetsIconsNavigationBarGen get navigationBar =>
      const $AssetsIconsNavigationBarGen();

  /// Directory path: assets/icons/news
  $AssetsIconsNewsGen get news => const $AssetsIconsNewsGen();

  /// Directory path: assets/icons/poll_detail_page
  $AssetsIconsPollDetailPageGen get pollDetailPage =>
      const $AssetsIconsPollDetailPageGen();

  /// Directory path: assets/icons/quick_links
  $AssetsIconsQuickLinksGen get quickLinks => const $AssetsIconsQuickLinksGen();

  /// Directory path: assets/icons/quick_links_widget
  $AssetsIconsQuickLinksWidgetGen get quickLinksWidget =>
      const $AssetsIconsQuickLinksWidgetGen();

  /// Directory path: assets/icons/requests
  $AssetsIconsRequestsGen get requests => const $AssetsIconsRequestsGen();

  /// Directory path: assets/icons/resale
  $AssetsIconsResaleGen get resale => const $AssetsIconsResaleGen();

  /// Directory path: assets/icons/resale_page
  $AssetsIconsResalePageGen get resalePage => const $AssetsIconsResalePageGen();

  /// Directory path: assets/icons/tab_bar
  $AssetsIconsTabBarGen get tabBar => const $AssetsIconsTabBarGen();

  /// Directory path: assets/icons/text_field
  $AssetsIconsTextFieldGen get textField => const $AssetsIconsTextFieldGen();

  /// Directory path: assets/icons/user_kpi
  $AssetsIconsUserKpiGen get userKpi => const $AssetsIconsUserKpiGen();

  /// Directory path: assets/icons/user_profile
  $AssetsIconsUserProfileGen get userProfile =>
      const $AssetsIconsUserProfileGen();
}

class $AssetsPollsGen {
  const $AssetsPollsGen();

  /// File path: assets/polls/poll_001.json
  String get poll001 => 'assets/polls/poll_001.json';

  /// List of all assets
  List<String> get values => [poll001];
}

class $AssetsIconsAuthGen {
  const $AssetsIconsAuthGen();

  /// File path: assets/icons/auth/face_id_big.svg
  SvgGenImage get faceIdBig =>
      const SvgGenImage('assets/icons/auth/face_id_big.svg');

  /// File path: assets/icons/auth/touch_id_big.svg
  SvgGenImage get touchIdBig =>
      const SvgGenImage('assets/icons/auth/touch_id_big.svg');

  /// List of all assets
  List<SvgGenImage> get values => [faceIdBig, touchIdBig];
}

class $AssetsIconsBenefitContentGen {
  const $AssetsIconsBenefitContentGen();

  /// File path: assets/icons/benefit_content/chat_bubble_outline.svg
  SvgGenImage get chatBubbleOutline =>
      const SvgGenImage('assets/icons/benefit_content/chat_bubble_outline.svg');

  /// File path: assets/icons/benefit_content/dowenload_doc_button.svg
  SvgGenImage get dowenloadDocButton => const SvgGenImage(
    'assets/icons/benefit_content/dowenload_doc_button.svg',
  );

  /// File path: assets/icons/benefit_content/favorite.svg
  SvgGenImage get favorite =>
      const SvgGenImage('assets/icons/benefit_content/favorite.svg');

  /// File path: assets/icons/benefit_content/favorite_border.svg
  SvgGenImage get favoriteBorder =>
      const SvgGenImage('assets/icons/benefit_content/favorite_border.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    chatBubbleOutline,
    dowenloadDocButton,
    favorite,
    favoriteBorder,
  ];
}

class $AssetsIconsBenefitsWidgetGen {
  const $AssetsIconsBenefitsWidgetGen();

  /// File path: assets/icons/benefits_widget/additional_insurance_widget_icon.svg
  SvgGenImage get additionalInsuranceWidgetIcon => const SvgGenImage(
    'assets/icons/benefits_widget/additional_insurance_widget_icon.svg',
  );

  /// File path: assets/icons/benefits_widget/discount_widget_icon.svg
  SvgGenImage get discountWidgetIcon => const SvgGenImage(
    'assets/icons/benefits_widget/discount_widget_icon.svg',
  );

  /// File path: assets/icons/benefits_widget/inshurance_med_widget_icon.svg
  SvgGenImage get inshuranceMedWidgetIcon => const SvgGenImage(
    'assets/icons/benefits_widget/inshurance_med_widget_icon.svg',
  );

  /// File path: assets/icons/benefits_widget/labor_remuneration_widget_icon.svg
  SvgGenImage get laborRemunerationWidgetIcon => const SvgGenImage(
    'assets/icons/benefits_widget/labor_remuneration_widget_icon.svg',
  );

  /// File path: assets/icons/benefits_widget/material_assistance_widget_icon.svg
  SvgGenImage get materialAssistanceWidgetIcon => const SvgGenImage(
    'assets/icons/benefits_widget/material_assistance_widget_icon.svg',
  );

  /// File path: assets/icons/benefits_widget/prime_zone_widget_icon.svg
  SvgGenImage get primeZoneWidgetIcon => const SvgGenImage(
    'assets/icons/benefits_widget/prime_zone_widget_icon.svg',
  );

  /// File path: assets/icons/benefits_widget/shopping.svg
  SvgGenImage get shopping =>
      const SvgGenImage('assets/icons/benefits_widget/shopping.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    additionalInsuranceWidgetIcon,
    discountWidgetIcon,
    inshuranceMedWidgetIcon,
    laborRemunerationWidgetIcon,
    materialAssistanceWidgetIcon,
    primeZoneWidgetIcon,
    shopping,
  ];
}

class $AssetsIconsChatGen {
  const $AssetsIconsChatGen();

  /// File path: assets/icons/chat/chat_attachment.svg
  SvgGenImage get chatAttachment =>
      const SvgGenImage('assets/icons/chat/chat_attachment.svg');

  /// File path: assets/icons/chat/chat_file.svg
  SvgGenImage get chatFile =>
      const SvgGenImage('assets/icons/chat/chat_file.svg');

  /// File path: assets/icons/chat/chat_send_message.svg
  SvgGenImage get chatSendMessage =>
      const SvgGenImage('assets/icons/chat/chat_send_message.svg');

  /// File path: assets/icons/chat/delete_replay.svg
  SvgGenImage get deleteReplay =>
      const SvgGenImage('assets/icons/chat/delete_replay.svg');

  /// File path: assets/icons/chat/like_pressed.svg
  SvgGenImage get likePressed =>
      const SvgGenImage('assets/icons/chat/like_pressed.svg');

  /// File path: assets/icons/chat/like_unpressed.svg
  SvgGenImage get likeUnpressed =>
      const SvgGenImage('assets/icons/chat/like_unpressed.svg');

  /// File path: assets/icons/chat/replay_divider.svg
  SvgGenImage get replayDivider =>
      const SvgGenImage('assets/icons/chat/replay_divider.svg');

  /// File path: assets/icons/chat/reply_icon.svg
  SvgGenImage get replyIcon =>
      const SvgGenImage('assets/icons/chat/reply_icon.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    chatAttachment,
    chatFile,
    chatSendMessage,
    deleteReplay,
    likePressed,
    likeUnpressed,
    replayDivider,
    replyIcon,
  ];
}

class $AssetsIconsCommonGen {
  const $AssetsIconsCommonGen();

  /// File path: assets/icons/common/checkbox_outline_green.svg
  SvgGenImage get checkboxOutlineGreen =>
      const SvgGenImage('assets/icons/common/checkbox_outline_green.svg');

  /// File path: assets/icons/common/time.svg
  SvgGenImage get time => const SvgGenImage('assets/icons/common/time.svg');

  /// List of all assets
  List<SvgGenImage> get values => [checkboxOutlineGreen, time];
}

class $AssetsIconsDemoGen {
  const $AssetsIconsDemoGen();

  /// File path: assets/icons/demo/sample.jpg
  AssetGenImage get sample =>
      const AssetGenImage('assets/icons/demo/sample.jpg');

  /// List of all assets
  List<AssetGenImage> get values => [sample];
}

class $AssetsIconsKeyboardGen {
  const $AssetsIconsKeyboardGen();

  /// File path: assets/icons/keyboard/backspace.svg
  SvgGenImage get backspace =>
      const SvgGenImage('assets/icons/keyboard/backspace.svg');

  /// File path: assets/icons/keyboard/face_id.svg
  SvgGenImage get faceId =>
      const SvgGenImage('assets/icons/keyboard/face_id.svg');

  /// File path: assets/icons/keyboard/touch_id.svg
  SvgGenImage get touchId =>
      const SvgGenImage('assets/icons/keyboard/touch_id.svg');

  /// List of all assets
  List<SvgGenImage> get values => [backspace, faceId, touchId];
}

class $AssetsIconsMorePageGen {
  const $AssetsIconsMorePageGen();

  /// File path: assets/icons/more_page/shevron_right.svg
  SvgGenImage get shevronRight =>
      const SvgGenImage('assets/icons/more_page/shevron_right.svg');

  /// List of all assets
  List<SvgGenImage> get values => [shevronRight];
}

class $AssetsIconsNavigationBarGen {
  const $AssetsIconsNavigationBarGen();

  /// File path: assets/icons/navigation_bar/back.svg
  SvgGenImage get back =>
      const SvgGenImage('assets/icons/navigation_bar/back.svg');

  /// File path: assets/icons/navigation_bar/back_white.svg
  SvgGenImage get backWhite =>
      const SvgGenImage('assets/icons/navigation_bar/back_white.svg');

  /// File path: assets/icons/navigation_bar/bell_alert.svg
  SvgGenImage get bellAlert =>
      const SvgGenImage('assets/icons/navigation_bar/bell_alert.svg');

  /// File path: assets/icons/navigation_bar/close.svg
  SvgGenImage get close =>
      const SvgGenImage('assets/icons/navigation_bar/close.svg');

  /// File path: assets/icons/navigation_bar/exit.svg
  SvgGenImage get exit =>
      const SvgGenImage('assets/icons/navigation_bar/exit.svg');

  /// File path: assets/icons/navigation_bar/exit_delete.svg
  SvgGenImage get exitDelete =>
      const SvgGenImage('assets/icons/navigation_bar/exit_delete.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    back,
    backWhite,
    bellAlert,
    close,
    exit,
    exitDelete,
  ];
}

class $AssetsIconsNewsGen {
  const $AssetsIconsNewsGen();

  /// File path: assets/icons/news/news_categories_selector.svg
  SvgGenImage get newsCategoriesSelector =>
      const SvgGenImage('assets/icons/news/news_categories_selector.svg');

  /// List of all assets
  List<SvgGenImage> get values => [newsCategoriesSelector];
}

class $AssetsIconsPollDetailPageGen {
  const $AssetsIconsPollDetailPageGen();

  /// File path: assets/icons/poll_detail_page/poll_passed.svg
  SvgGenImage get pollPassed =>
      const SvgGenImage('assets/icons/poll_detail_page/poll_passed.svg');

  /// List of all assets
  List<SvgGenImage> get values => [pollPassed];
}

class $AssetsIconsQuickLinksGen {
  const $AssetsIconsQuickLinksGen();

  /// File path: assets/icons/quick_links/quick_links_confluence.svg
  SvgGenImage get quickLinksConfluence =>
      const SvgGenImage('assets/icons/quick_links/quick_links_confluence.svg');

  /// File path: assets/icons/quick_links/quick_links_ispring.svg
  SvgGenImage get quickLinksIspring =>
      const SvgGenImage('assets/icons/quick_links/quick_links_ispring.svg');

  /// File path: assets/icons/quick_links/quick_links_jira.svg
  SvgGenImage get quickLinksJira =>
      const SvgGenImage('assets/icons/quick_links/quick_links_jira.svg');

  /// File path: assets/icons/quick_links/quick_links_potok.svg
  SvgGenImage get quickLinksPotok =>
      const SvgGenImage('assets/icons/quick_links/quick_links_potok.svg');

  /// File path: assets/icons/quick_links/quick_links_telegram.svg
  SvgGenImage get quickLinksTelegram =>
      const SvgGenImage('assets/icons/quick_links/quick_links_telegram.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    quickLinksConfluence,
    quickLinksIspring,
    quickLinksJira,
    quickLinksPotok,
    quickLinksTelegram,
  ];
}

class $AssetsIconsQuickLinksWidgetGen {
  const $AssetsIconsQuickLinksWidgetGen();

  /// File path: assets/icons/quick_links_widget/quick_links_widget_confluence.svg
  SvgGenImage get quickLinksWidgetConfluence => const SvgGenImage(
    'assets/icons/quick_links_widget/quick_links_widget_confluence.svg',
  );

  /// File path: assets/icons/quick_links_widget/quick_links_widget_ispring.svg
  SvgGenImage get quickLinksWidgetIspring => const SvgGenImage(
    'assets/icons/quick_links_widget/quick_links_widget_ispring.svg',
  );

  /// File path: assets/icons/quick_links_widget/quick_links_widget_jira.svg
  SvgGenImage get quickLinksWidgetJira => const SvgGenImage(
    'assets/icons/quick_links_widget/quick_links_widget_jira.svg',
  );

  /// File path: assets/icons/quick_links_widget/quick_links_widget_podok.svg
  SvgGenImage get quickLinksWidgetPodok => const SvgGenImage(
    'assets/icons/quick_links_widget/quick_links_widget_podok.svg',
  );

  /// File path: assets/icons/quick_links_widget/quick_links_widget_telegram.svg
  SvgGenImage get quickLinksWidgetTelegram => const SvgGenImage(
    'assets/icons/quick_links_widget/quick_links_widget_telegram.svg',
  );

  /// List of all assets
  List<SvgGenImage> get values => [
    quickLinksWidgetConfluence,
    quickLinksWidgetIspring,
    quickLinksWidgetJira,
    quickLinksWidgetPodok,
    quickLinksWidgetTelegram,
  ];
}

class $AssetsIconsRequestsGen {
  const $AssetsIconsRequestsGen();

  /// File path: assets/icons/requests/request_absence.svg
  SvgGenImage get requestAbsence =>
      const SvgGenImage('assets/icons/requests/request_absence.svg');

  /// File path: assets/icons/requests/request_alpina_access.svg
  SvgGenImage get requestAlpinaAccess =>
      const SvgGenImage('assets/icons/requests/request_alpina_access.svg');

  /// File path: assets/icons/requests/request_business_trip.svg
  SvgGenImage get requestBusinessTrip =>
      const SvgGenImage('assets/icons/requests/request_business_trip.svg');

  /// File path: assets/icons/requests/request_courier.svg
  SvgGenImage get requestCourier =>
      const SvgGenImage('assets/icons/requests/request_courier.svg');

  /// File path: assets/icons/requests/request_dpo.svg
  SvgGenImage get requestDpo =>
      const SvgGenImage('assets/icons/requests/request_dpo.svg');

  /// File path: assets/icons/requests/request_internal_training.svg
  SvgGenImage get requestInternalTraining =>
      const SvgGenImage('assets/icons/requests/request_internal_training.svg');

  /// File path: assets/icons/requests/request_parking.svg
  SvgGenImage get requestParking =>
      const SvgGenImage('assets/icons/requests/request_parking.svg');

  /// File path: assets/icons/requests/request_pass.svg
  SvgGenImage get requestPass =>
      const SvgGenImage('assets/icons/requests/request_pass.svg');

  /// File path: assets/icons/requests/request_referral.svg
  SvgGenImage get requestReferral =>
      const SvgGenImage('assets/icons/requests/request_referral.svg');

  /// File path: assets/icons/requests/request_unplanned_training.svg
  SvgGenImage get requestUnplannedTraining =>
      const SvgGenImage('assets/icons/requests/request_unplanned_training.svg');

  /// File path: assets/icons/requests/request_violation.svg
  SvgGenImage get requestViolation =>
      const SvgGenImage('assets/icons/requests/request_violation.svg');

  /// File path: assets/icons/requests/request_work_book_copy.svg
  SvgGenImage get requestWorkBookCopy =>
      const SvgGenImage('assets/icons/requests/request_work_book_copy.svg');

  /// File path: assets/icons/requests/request_work_certificate.svg
  SvgGenImage get requestWorkCertificate =>
      const SvgGenImage('assets/icons/requests/request_work_certificate.svg');

  /// File path: assets/icons/requests/tax_certificate.svg
  SvgGenImage get taxCertificate =>
      const SvgGenImage('assets/icons/requests/tax_certificate.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    requestAbsence,
    requestAlpinaAccess,
    requestBusinessTrip,
    requestCourier,
    requestDpo,
    requestInternalTraining,
    requestParking,
    requestPass,
    requestReferral,
    requestUnplannedTraining,
    requestViolation,
    requestWorkBookCopy,
    requestWorkCertificate,
    taxCertificate,
  ];
}

class $AssetsIconsResaleGen {
  const $AssetsIconsResaleGen();

  /// File path: assets/icons/resale/chat.svg
  SvgGenImage get chat => const SvgGenImage('assets/icons/resale/chat.svg');

  /// File path: assets/icons/resale/closed_lock.svg
  SvgGenImage get closedLock =>
      const SvgGenImage('assets/icons/resale/closed_lock.svg');

  /// File path: assets/icons/resale/download_icon.svg
  SvgGenImage get downloadIcon =>
      const SvgGenImage('assets/icons/resale/download_icon.svg');

  /// File path: assets/icons/resale/open_lock.svg
  SvgGenImage get openLock =>
      const SvgGenImage('assets/icons/resale/open_lock.svg');

  /// File path: assets/icons/resale/status_ok.svg
  SvgGenImage get statusOk =>
      const SvgGenImage('assets/icons/resale/status_ok.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    chat,
    closedLock,
    downloadIcon,
    openLock,
    statusOk,
  ];
}

class $AssetsIconsResalePageGen {
  const $AssetsIconsResalePageGen();

  /// File path: assets/icons/resale_page/closed_lock_page.svg
  SvgGenImage get closedLockPage =>
      const SvgGenImage('assets/icons/resale_page/closed_lock_page.svg');

  /// File path: assets/icons/resale_page/open_lock_page.svg
  SvgGenImage get openLockPage =>
      const SvgGenImage('assets/icons/resale_page/open_lock_page.svg');

  /// List of all assets
  List<SvgGenImage> get values => [closedLockPage, openLockPage];
}

class $AssetsIconsTabBarGen {
  const $AssetsIconsTabBarGen();

  /// File path: assets/icons/tab_bar/tab_bar_home.svg
  SvgGenImage get tabBarHome =>
      const SvgGenImage('assets/icons/tab_bar/tab_bar_home.svg');

  /// File path: assets/icons/tab_bar/tab_bar_home_filled.svg
  SvgGenImage get tabBarHomeFilled =>
      const SvgGenImage('assets/icons/tab_bar/tab_bar_home_filled.svg');

  /// File path: assets/icons/tab_bar/tab_bar_more.svg
  SvgGenImage get tabBarMore =>
      const SvgGenImage('assets/icons/tab_bar/tab_bar_more.svg');

  /// File path: assets/icons/tab_bar/tab_bar_more_filled.svg
  SvgGenImage get tabBarMoreFilled =>
      const SvgGenImage('assets/icons/tab_bar/tab_bar_more_filled.svg');

  /// File path: assets/icons/tab_bar/tab_bar_requests.svg
  SvgGenImage get tabBarRequests =>
      const SvgGenImage('assets/icons/tab_bar/tab_bar_requests.svg');

  /// File path: assets/icons/tab_bar/tab_bar_requests_filled.svg
  SvgGenImage get tabBarRequestsFilled =>
      const SvgGenImage('assets/icons/tab_bar/tab_bar_requests_filled.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    tabBarHome,
    tabBarHomeFilled,
    tabBarMore,
    tabBarMoreFilled,
    tabBarRequests,
    tabBarRequestsFilled,
  ];
}

class $AssetsIconsTextFieldGen {
  const $AssetsIconsTextFieldGen();

  /// File path: assets/icons/text_field/calendar.svg
  SvgGenImage get calendar =>
      const SvgGenImage('assets/icons/text_field/calendar.svg');

  /// File path: assets/icons/text_field/chevron_down.svg
  SvgGenImage get chevronDown =>
      const SvgGenImage('assets/icons/text_field/chevron_down.svg');

  /// File path: assets/icons/text_field/clock.svg
  SvgGenImage get clock =>
      const SvgGenImage('assets/icons/text_field/clock.svg');

  /// File path: assets/icons/text_field/close.svg
  SvgGenImage get close =>
      const SvgGenImage('assets/icons/text_field/close.svg');

  /// File path: assets/icons/text_field/close_circle_blue.svg
  SvgGenImage get closeCircleBlue =>
      const SvgGenImage('assets/icons/text_field/close_circle_blue.svg');

  /// File path: assets/icons/text_field/eye_off.svg
  SvgGenImage get eyeOff =>
      const SvgGenImage('assets/icons/text_field/eye_off.svg');

  /// File path: assets/icons/text_field/eye_on.svg
  SvgGenImage get eyeOn =>
      const SvgGenImage('assets/icons/text_field/eye_on.svg');

  /// File path: assets/icons/text_field/trash.svg
  SvgGenImage get trash =>
      const SvgGenImage('assets/icons/text_field/trash.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    calendar,
    chevronDown,
    clock,
    close,
    closeCircleBlue,
    eyeOff,
    eyeOn,
    trash,
  ];
}

class $AssetsIconsUserKpiGen {
  const $AssetsIconsUserKpiGen();

  /// File path: assets/icons/user_kpi/chevron_left.svg
  SvgGenImage get chevronLeft =>
      const SvgGenImage('assets/icons/user_kpi/chevron_left.svg');

  /// File path: assets/icons/user_kpi/chevron_right.svg
  SvgGenImage get chevronRight =>
      const SvgGenImage('assets/icons/user_kpi/chevron_right.svg');

  /// List of all assets
  List<SvgGenImage> get values => [chevronLeft, chevronRight];
}

class $AssetsIconsUserProfileGen {
  const $AssetsIconsUserProfileGen();

  /// File path: assets/icons/user_profile/open_kpi.svg
  SvgGenImage get openKpi =>
      const SvgGenImage('assets/icons/user_profile/open_kpi.svg');

  /// List of all assets
  List<SvgGenImage> get values => [openKpi];
}

class Assets {
  const Assets._();

  static const $AssetsIconsGen icons = $AssetsIconsGen();
  static const $AssetsPollsGen polls = $AssetsPollsGen();
}

class AssetGenImage {
  const AssetGenImage(this._assetName, {this.size, this.flavors = const {}});

  final String _assetName;

  final Size? size;
  final Set<String> flavors;

  Image image({
    Key? key,
    AssetBundle? bundle,
    ImageFrameBuilder? frameBuilder,
    ImageErrorWidgetBuilder? errorBuilder,
    String? semanticLabel,
    bool excludeFromSemantics = false,
    double? scale,
    double? width,
    double? height,
    Color? color,
    Animation<double>? opacity,
    BlendMode? colorBlendMode,
    BoxFit? fit,
    AlignmentGeometry alignment = Alignment.center,
    ImageRepeat repeat = ImageRepeat.noRepeat,
    Rect? centerSlice,
    bool matchTextDirection = false,
    bool gaplessPlayback = true,
    bool isAntiAlias = false,
    String? package,
    FilterQuality filterQuality = FilterQuality.medium,
    int? cacheWidth,
    int? cacheHeight,
  }) {
    return Image.asset(
      _assetName,
      key: key,
      bundle: bundle,
      frameBuilder: frameBuilder,
      errorBuilder: errorBuilder,
      semanticLabel: semanticLabel,
      excludeFromSemantics: excludeFromSemantics,
      scale: scale,
      width: width,
      height: height,
      color: color,
      opacity: opacity,
      colorBlendMode: colorBlendMode,
      fit: fit,
      alignment: alignment,
      repeat: repeat,
      centerSlice: centerSlice,
      matchTextDirection: matchTextDirection,
      gaplessPlayback: gaplessPlayback,
      isAntiAlias: isAntiAlias,
      package: package,
      filterQuality: filterQuality,
      cacheWidth: cacheWidth,
      cacheHeight: cacheHeight,
    );
  }

  ImageProvider provider({AssetBundle? bundle, String? package}) {
    return AssetImage(_assetName, bundle: bundle, package: package);
  }

  String get path => _assetName;

  String get keyName => _assetName;
}

class SvgGenImage {
  const SvgGenImage(this._assetName, {this.size, this.flavors = const {}})
    : _isVecFormat = false;

  const SvgGenImage.vec(this._assetName, {this.size, this.flavors = const {}})
    : _isVecFormat = true;

  final String _assetName;
  final Size? size;
  final Set<String> flavors;
  final bool _isVecFormat;

  _svg.SvgPicture svg({
    Key? key,
    bool matchTextDirection = false,
    AssetBundle? bundle,
    String? package,
    double? width,
    double? height,
    BoxFit fit = BoxFit.contain,
    AlignmentGeometry alignment = Alignment.center,
    bool allowDrawingOutsideViewBox = false,
    WidgetBuilder? placeholderBuilder,
    String? semanticsLabel,
    bool excludeFromSemantics = false,
    _svg.SvgTheme? theme,
    ColorFilter? colorFilter,
    Clip clipBehavior = Clip.hardEdge,
    @deprecated Color? color,
    @deprecated BlendMode colorBlendMode = BlendMode.srcIn,
    @deprecated bool cacheColorFilter = false,
  }) {
    final _svg.BytesLoader loader;
    if (_isVecFormat) {
      loader = _vg.AssetBytesLoader(
        _assetName,
        assetBundle: bundle,
        packageName: package,
      );
    } else {
      loader = _svg.SvgAssetLoader(
        _assetName,
        assetBundle: bundle,
        packageName: package,
        theme: theme,
      );
    }
    return _svg.SvgPicture(
      loader,
      key: key,
      matchTextDirection: matchTextDirection,
      width: width,
      height: height,
      fit: fit,
      alignment: alignment,
      allowDrawingOutsideViewBox: allowDrawingOutsideViewBox,
      placeholderBuilder: placeholderBuilder,
      semanticsLabel: semanticsLabel,
      excludeFromSemantics: excludeFromSemantics,
      colorFilter:
          colorFilter ??
          (color == null ? null : ColorFilter.mode(color, colorBlendMode)),
      clipBehavior: clipBehavior,
      cacheColorFilter: cacheColorFilter,
    );
  }

  String get path => _assetName;

  String get keyName => _assetName;
}
