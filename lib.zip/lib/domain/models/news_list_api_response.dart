import 'package:hr_tcc/models/models.dart';

class NewsListApiResponse {
  final List<NewsCardModel> listNews;

  NewsListApiResponse({required this.listNews});
}
