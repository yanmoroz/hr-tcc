abstract class CarBrandRepository {
  Future<List<String>> getCarBrands();
}
