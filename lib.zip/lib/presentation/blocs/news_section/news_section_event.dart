part of 'news_section_bloc.dart';

abstract class NewsSectionEvent {}

class LoadNewsSection extends NewsSectionEvent {}
