part of 'benefits_list_category_page_bloc.dart';

abstract class BenefitsListCategoryPageEvent {}

class LoadBenefitsListCategoryPage extends BenefitsListCategoryPageEvent {}
