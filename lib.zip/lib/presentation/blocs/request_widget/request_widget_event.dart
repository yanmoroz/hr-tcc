part of 'request_widget_bloc.dart';

abstract class RequestsWidgetEvent {
  const RequestsWidgetEvent();
}

class RequestsWidgetLoad extends RequestsWidgetEvent {}