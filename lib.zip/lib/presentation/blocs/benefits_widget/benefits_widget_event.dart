part of 'benefits_widget_bloc.dart';

abstract class BenefitsWidgetEvent {}

class LoadBenefitsWidgetItems extends BenefitsWidgetEvent {}
