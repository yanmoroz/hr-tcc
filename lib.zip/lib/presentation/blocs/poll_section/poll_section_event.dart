part of 'poll_section_bloc.dart';

abstract class PollSectionEvent {}

class LoadPolls extends PollSectionEvent {}
