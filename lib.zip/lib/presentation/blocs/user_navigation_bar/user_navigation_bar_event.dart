part of 'user_navigation_bar_bloc.dart';

abstract class NavigationBarOnMainEvent {}

class UserNavigationBarLoad extends NavigationBarOnMainEvent {}

class NavigationBarOnMainTapOnBell extends NavigationBarOnMainEvent {}
