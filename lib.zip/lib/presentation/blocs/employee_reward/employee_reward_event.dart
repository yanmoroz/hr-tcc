part of 'employee_reward_bloc.dart';

abstract class EmployeeRewardEvent {}

class EmployeeRewardLoaded extends EmployeeRewardEvent {}
