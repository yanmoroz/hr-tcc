part of 'benefits_list_categories_page_bloc.dart';

abstract class BenefitsListCategoriesPageEvent {}

class LoadBenefitsListCategoriesPage extends BenefitsListCategoriesPageEvent {}
