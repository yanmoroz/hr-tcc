part of 'more_page_bloc.dart';

abstract class MorePageEvent {}

class LoadMenu extends MorePageEvent {}

class LoadMenuCounts extends MorePageEvent {}
